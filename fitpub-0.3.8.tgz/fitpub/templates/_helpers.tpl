{{/*
Expand the name of the chart.
*/}}
{{- define "fitpub.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "fitpub.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "fitpub.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "fitpub.labels" -}}
helm.sh/chart: {{ include "fitpub.chart" . }}
{{ include "fitpub.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . | trim }}
{{- end }}
{{- end }}

{{/*
Common annotations for all resources. Accepts a dict of resource-specific
annotations as .annotations and the root context as .context.
Usage: {{- include "fitpub.annotations" (dict "annotations" .Values.service.annotations "context" $) | nindent 4 }}
*/}}
{{- define "fitpub.annotations" -}}
{{- $merged := merge (deepCopy (default (dict) .annotations)) (default (dict) .context.Values.commonAnnotations) -}}
{{- if $merged -}}
{{- toYaml $merged }}
{{- end -}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "fitpub.selectorLabels" -}}
app.kubernetes.io/name: {{ include "fitpub.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "fitpub.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "fitpub.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create the name of the ConfigMap used for non-secret environment variables.
*/}}
{{- define "fitpub.configMapName" -}}
{{- printf "%s-config" (include "fitpub.fullname" .) }}
{{- end }}

{{/*
Create the name of the Secret used for secret environment variables.
*/}}
{{- define "fitpub.secretName" -}}
{{- default (printf "%s-secret" (include "fitpub.fullname" .)) .Values.applicationSecret.existingSecret }}
{{- end }}
